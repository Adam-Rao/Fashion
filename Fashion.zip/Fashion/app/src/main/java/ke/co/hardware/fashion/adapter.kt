package ke.co.hardware.fashion

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import kotlin.collections.ArrayList
import ke.co.hardware.fashion.R
import kotlinx.android.synthetic.main.grid_picture.view.*

class MovieListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    val text=itemView.text_detail
    val image:ImageView=itemView.image



}
class item_adapter{
    var detail=""
    var uri=""
    var id=1
}
class adapter(var item:ArrayList<item_adapter>):RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return MovieListViewHolder(LayoutInflater.from(parent.context).inflate(ke.co.hardware.fashion.R.layout.grid_picture, parent, false))
    }

    override fun getItemCount(): Int = item.size

    override fun onBindViewHolder(viewHolder: RecyclerView.ViewHolder, position: Int) {
        val movieViewHolder = viewHolder as MovieListViewHolder
        //movieViewHolder.bindView(listOfMovies[position])
    }

    fun setMovieList(listOfMovies: ArrayList<item_adapter>) {
        this.item = listOfMovies
        notifyDataSetChanged()
    }
}