package ke.co.hardware.fashion


import android.content.ContentValues
import android.os.Bundle
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.android.gms.tasks.OnFailureListener
import com.google.firebase.storage.FileDownloadTask
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.firestore.FirebaseFirestore
import java.io.File


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 *
 */


class shoes : Fragment() {

    lateinit var v:View
    val items=ArrayList<item_adapter>()
    var mStorageRef: StorageReference? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        v= inflater.inflate(R.layout.fragment_shoes, container, false)

        val db = FirebaseFirestore.getInstance()

        /*mStorageRef = FirebaseStorage.getInstance().getReference();

        val riversRef = mStorageRef!!.child("images/rivers.jpg")

        val localFile = File.createTempFile("images", "jpg")
        riversRef.getFile(localFile)
            .addOnSuccessListener(OnSuccessListener<FileDownloadTask.TaskSnapshot> {
                // Successfully downloaded data to local file
                // ...
            }).addOnFailureListener(OnFailureListener {
                // Handle failed download
                // ...
            })*/

        val docRef = db.collection("shopping").document("shoes")
        docRef.get()
            .addOnSuccessListener { document ->
                if (document != null || document!!.data!=null ) {
                    Log.d(ContentValues.TAG, "DocumentSnapshot data: " + document.data)
                    if(document.data==null){
                       // updateUI(mAuth.currentUser)
                    }
                    else{
                        val doc=document as ArrayList<Array<String>>
                        Log.d("documents",doc.toString())
                    }

                } else {
                   // updateUI(mAuth.currentUser)
                }
            }
            .addOnFailureListener { exception ->
                Log.d(ContentValues.TAG, "get failed with ", exception)
            }

        return v
    }



}
